function draw_reconstructions(P_orig, P_rec)

for i = 1 : size(P_orig,2)
    plot([P_orig(1,i), P_rec(1,i) ] , [P_orig(2,i), P_rec(2,i) ],'k') ;
end

yq = [4.3138 2.6777];

plot(P_orig(1,:), P_orig(2,:),'ob') ;
% plot(P_rec(1,:), P_rec(2,:),'xb') ;


plot([P_rec(1,:) yq(1)] , [P_rec(2,:) yq(2)], 'xg')
